package Task::BeLike::FIBO;

our $VERSION = '0.02';

1;

__END__

=head1 NAME

Task::BeLike::FIBO - Leonardo Pisano a.k.a. Fibonacci

=cut

